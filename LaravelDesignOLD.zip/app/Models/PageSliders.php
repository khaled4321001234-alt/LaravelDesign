<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PageSliders extends Model
{
    use HasFactory;

    protected $table = 'page_sliders';
    protected $guarded = [];
}
